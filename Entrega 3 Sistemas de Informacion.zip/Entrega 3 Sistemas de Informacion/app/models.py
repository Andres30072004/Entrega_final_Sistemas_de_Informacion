# app/models.py
from sqlalchemy import Column, Integer, String, Float, Text, DateTime, ForeignKey, Boolean
from sqlalchemy.orm import relationship
from datetime import datetime
from .database import Base

class Property(Base):
    __tablename__ = "properties"
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(200), nullable=False)
    description = Column(Text, nullable=True)
    owner_name = Column(String(120), nullable=False)
    owner_email = Column(String(120), nullable=False)
    area_m2 = Column(Float, nullable=False)
    price = Column(Float, nullable=False)
    property_type = Column(String(80), nullable=False)  # e.g., 'Apartamento', 'Casa'
    city = Column(String(80), nullable=True)
    status = Column(String(40), default="captada")  # captada, validada, pendiente, publicada
    created_at = Column(DateTime, default=datetime.utcnow)
    validated = Column(Boolean, default=False)

    documents = relationship("Document", back_populates="property", cascade="all, delete-orphan")

class Document(Base):
    __tablename__ = "documents"
    id = Column(Integer, primary_key=True, index=True)
    property_id = Column(Integer, ForeignKey("properties.id"))
    filename = Column(String(255))
    filetype = Column(String(50))
    path = Column(String(500))
    uploaded_at = Column(DateTime, default=datetime.utcnow)

    property = relationship("Property", back_populates="documents")
