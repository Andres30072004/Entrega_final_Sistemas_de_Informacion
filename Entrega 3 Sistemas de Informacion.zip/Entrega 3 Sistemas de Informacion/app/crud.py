# app/crud.py
from sqlalchemy.orm import Session
from . import models, schemas
from typing import List

def create_property(db: Session, prop: schemas.PropertyCreate) -> models.Property:
    db_prop = models.Property(
        title=prop.title,
        description=prop.description,
        owner_name=prop.owner_name,
        owner_email=prop.owner_email,
        area_m2=prop.area_m2,
        price=prop.price,
        property_type=prop.property_type,
        city=prop.city
    )
    db.add(db_prop)
    db.commit()
    db.refresh(db_prop)
    return db_prop

def get_property(db: Session, property_id: int):
    return db.query(models.Property).filter(models.Property.id == property_id).first()

def list_properties(db: Session, skip:int=0, limit:int=100):
    return db.query(models.Property).offset(skip).limit(limit).all()

def add_document(db: Session, property_id:int, filename:str, filetype:str, path:str):
    doc = models.Document(property_id=property_id, filename=filename, filetype=filetype, path=path)
    db.add(doc)
    db.commit()
    db.refresh(doc)
    return doc

def set_validated(db: Session, property_id:int, validated:bool=True, status:str="validada"):
    prop = get_property(db, property_id)
    if not prop:
        return None
    prop.validated = validated
    prop.status = status
    db.commit()
    db.refresh(prop)
    return prop

def update_status(db: Session, property_id:int, status:str):
    prop = get_property(db, property_id)
    if not prop:
        return None
    prop.status = status
    db.commit()
    db.refresh(prop)
    return prop
