# app/sindication.py
import requests
from typing import Dict
import time

# Simulación de sindicación con un mock endpoint
def send_to_portal_mock(property_data: Dict) -> Dict:
    # Simula latencia y respuesta
    time.sleep(1)
    return {"portal": "mock_portal", "status": "ok", "external_id": f"MOCK-{int(time.time())}"}

# Si tuvieras credenciales reales, la función podría usar requests.post a la API del portal
def send_to_portal(property_data: Dict, portal_url: str, api_key: str = None) -> Dict:
    headers = {}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    try:
        resp = requests.post(portal_url, json=property_data, headers=headers, timeout=10)
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        return {"error": str(e)}
