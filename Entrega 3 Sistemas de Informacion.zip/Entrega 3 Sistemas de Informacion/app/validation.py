# app/validation.py
from .models import Property
from typing import Tuple

def simple_business_rules(prop: Property, docs_count:int) -> Tuple[bool, list]:
    """
    Regresa (is_valid, reasons)
    Reglas de ejemplo:
     - Debe tener al menos 2 documentos (ej. cedula, escrituras/contrato).
     - Precio mínimo/área coherente (ej. price/area no muy bajo o negativo).
     - Area y tipo coherentes (ej. area > 10).
    """
    reasons = []
    if docs_count < 2:
        reasons.append("Faltan documentos obligatorios (mínimo 2).")
    if prop.area_m2 <= 0:
        reasons.append("Área inválida.")
    if prop.price <= 0:
        reasons.append("Precio inválido.")
    # regla simple de consistencia precio por metro
    price_per_m2 = prop.price / prop.area_m2 if prop.area_m2 else 0
    if price_per_m2 < 100000:  # umbral ejemplo
        reasons.append(f"Valor por m² inusualmente bajo: {price_per_m2:.2f}")
    # otras reglas pueden agregarse
    is_valid = len(reasons) == 0
    return is_valid, reasons
