# app/schemas.py
from pydantic import BaseModel, EmailStr
from typing import List, Optional
from datetime import datetime

class DocumentCreate(BaseModel):
    filename: str
    filetype: str
    path: str

class DocumentOut(BaseModel):
    id: int
    filename: str
    filetype: str
    path: str
    uploaded_at: datetime
    class Config:
        orm_mode = True

class PropertyCreate(BaseModel):
    title: str
    description: Optional[str] = None
    owner_name: str
    owner_email: EmailStr
    area_m2: float
    price: float
    property_type: str
    city: Optional[str] = None

class PropertyOut(BaseModel):
    id: int
    title: str
    description: Optional[str]
    owner_name: str
    owner_email: EmailStr
    area_m2: float
    price: float
    property_type: str
    city: Optional[str]
    status: str
    validated: bool
    documents: List[DocumentOut] = []
    created_at: datetime
    class Config:
        orm_mode = True
