# app/main.py
import os
from fastapi import FastAPI, UploadFile, File, Form, Depends, HTTPException, BackgroundTasks
from fastapi.responses import JSONResponse
from sqlalchemy.orm import Session
from . import models, schemas, crud, validation, sindication
from .database import engine, SessionLocal, Base
from typing import List
import shutil

# crear tablas
Base.metadata.create_all(bind=engine)

UPLOAD_DIR = os.path.join(os.path.dirname(__file__), "static_uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

app = FastAPI(title="Orbe CRM - Captacion API")

# dependency
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.post("/api/inmuebles/", response_model=schemas.PropertyOut)
async def create_inmueble(
    title: str = Form(...),
    description: str = Form(None),
    owner_name: str = Form(...),
    owner_email: str = Form(...),
    area_m2: float = Form(...),
    price: float = Form(...),
    property_type: str = Form(...),
    city: str = Form(None),
    files: List[UploadFile] = File([]),
    db: Session = Depends(get_db)
):
    # 1) crear registro base
    prop_in = schemas.PropertyCreate(
        title=title,
        description=description,
        owner_name=owner_name,
        owner_email=owner_email,
        area_m2=area_m2,
        price=price,
        property_type=property_type,
        city=city
    )
    db_prop = crud.create_property(db, prop_in)

    # 2) almacenar archivos
    saved_docs = []
    for f in files:
        safe_name = f"{db_prop.id}_{f.filename}"
        out_path = os.path.join(UPLOAD_DIR, safe_name)
        with open(out_path, "wb") as buffer:
            shutil.copyfileobj(f.file, buffer)
        doc = crud.add_document(db, db_prop.id, f.filename, f.content_type, out_path)
        saved_docs.append(doc)

    # 3) ejecutar validación automática
    is_valid, reasons = validation.simple_business_rules(db_prop, len(saved_docs))
    if is_valid:
        crud.set_validated(db, db_prop.id, True, status="validada")
    else:
        crud.update_status(db, db_prop.id, "pendiente")  # requiere revisión manual

    # devolver el registro
    db.refresh(db_prop)
    return db_prop

@app.get("/api/inmuebles/", response_model=List[schemas.PropertyOut])
def list_inmuebles(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    props = crud.list_properties(db, skip, limit)
    return props

@app.get("/api/inmuebles/{property_id}", response_model=schemas.PropertyOut)
def get_inmueble(property_id: int, db: Session = Depends(get_db)):
    prop = crud.get_property(db, property_id)
    if not prop:
        raise HTTPException(status_code=404, detail="Inmueble no encontrado")
    return prop

@app.post("/api/validacion/{property_id}")
def force_validacion(property_id: int, db: Session = Depends(get_db)):
    prop = crud.get_property(db, property_id)
    if not prop:
        raise HTTPException(status_code=404, detail="Inmueble no encontrado")
    docs_count = len(prop.documents)
    is_valid, reasons = validation.simple_business_rules(prop, docs_count)
    if is_valid:
        crud.set_validated(db, property_id, True, status="validada")
        return {"status": "validada"}
    else:
        crud.update_status(db, property_id, "pendiente")
        return {"status": "pendiente", "reasons": reasons}

@app.post("/api/sindicacion/{property_id}")
def sindicacion_endpoint(property_id: int, background_tasks: BackgroundTasks, db: Session = Depends(get_db)):
    prop = crud.get_property(db, property_id)
    if not prop:
        raise HTTPException(status_code=404, detail="Inmueble no encontrado")
    if not prop.validated:
        raise HTTPException(status_code=400, detail="Inmueble no validado.")
    # preparar payload simple
    payload = {
        "id": prop.id,
        "title": prop.title,
        "description": prop.description,
        "price": prop.price,
        "area_m2": prop.area_m2,
        "type": prop.property_type,
        "city": prop.city,
        "owner_name": prop.owner_name
    }
    # usar background task para no bloquear la respuesta
    background_tasks.add_task(_background_sindicacion, payload, db, property_id)
    # responder inmediatamente
    crud.update_status(db, property_id, "en_proceso_sindicacion")
    return {"status": "en_proceso_sindicacion"}

def _background_sindicacion(payload, db: Session, property_id:int):
    # ejemplo: enviamos a un portal mock y guardamos resultados en logs
    result = sindication.send_to_portal_mock(payload)
    # actualizar estado según respuesta
    if result.get("status") == "ok":
        crud.update_status(db, property_id, "publicada")
    else:
        crud.update_status(db, property_id, "error_sindicacion")

# endpoint health
@app.get("/api/health")
def health():
    return {"status": "ok"}
